import React from 'react';
import axios from 'axios';

const CountryTracks = () => <div>CountryTracks</div>;

export default CountryTracks;
